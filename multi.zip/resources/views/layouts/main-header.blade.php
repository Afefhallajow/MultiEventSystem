<!--=================================
header start-->

<section style="background-color: white" id="navigation1" class="">
<div  id="content">
    <img src="{{URL::asset('logo/1.png') }}" style="max-height: 140px" alt="Gantry 5"></div>
</section>
