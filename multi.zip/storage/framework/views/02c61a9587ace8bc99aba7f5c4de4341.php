<?php $__env->startSection('title'); ?>
    التسجيل ضمن الفعالية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style>   .card{

    max-width: 500px;
    margin: auto;
margin-top: 2%;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
            <!-- DataTales Example -->
                <div class="card shadow mb-2">
    <div class="card-body" style="text-align: center">
        <form style="text-align: center" method="post" action="<?php echo e(route('presence.store')); ?>" >
            <?php echo csrf_field(); ?>
            <div style="text-align: center" class="mb-5">
                <h3 align="center"> التسجيل ضمن الفعالية</h3>
            </div>
            <div class="row">
                <h5>اختر الفعالية</h5>
                <select class="form-control mb-2 " name="day" >
<?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($day->id); ?>" ><?php echo e($day->name); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
<div class="row">
    <h5> الرجاء ادخال المعرف الخاص بلمستخدم</h5>
    <input type="text" class="form-control" name="id">

</div>
            <br>
            <div class="">
            <BUTTON type="submit" class="btn btn-primary"> تسجيل</BUTTON>
            </div>

        </form>
    </div>

            </div></div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\multi\multi\resources\views/admin/Presence/new_presence.blade.php ENDPATH**/ ?>