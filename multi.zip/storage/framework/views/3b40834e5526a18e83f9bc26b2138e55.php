<?php $__env->startSection('title'); ?>
    إعدادات رسالة الواتس
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <!-- page title -->
            <?php echo $__env->make('admin.includes.page_title', ['title'=>'الفعاليات','supTitle' => 'إعدادات رسالة الواتس'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Content -->
            <form action="<?php echo e(url()->current()); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" class="form-control" name="type" id="" value="1"/>
                <input type="hidden" class="form-control" name="id" id="" />

                <label> السطر الأول من الرسالة</label>
                <input type="text" class="form-control" name="row1" value="<?php echo e($day->row1); ?>" id="whatsappMSGContent" />
                <label> السطر الثاني من الرسالة</label>
                <input type="text" class="form-control" name="row2" value="<?php echo e($day->row2); ?>" id="whatsappMSGlink" />
                <label> السطر الثالث من الرسالة</label>
                <input type="text" class="form-control" name="row3" value="<?php echo e($day->row3); ?>" id="whatsappMSGlink" />
                <label> السطر الرابع من الرسالة</label>
                <input type="text" class="form-control" name="row4" value="<?php echo e($day->row4); ?>" id="whatsappMSGlink" />
                <label> السطر الخامس من الرسالة</label>
                <input type="text" class="form-control" name="row5" value="<?php echo e($day->row5); ?>" id="whatsappMSGlink" />


                <label>Instance </label>
                <input type="text" class="form-control" dir="rtl" value="<?php echo e($day->instance); ?>" name="instance" id="whatsInstance" />
                <label>Token</label>
                <input type="text" class="form-control" dir="rtl"value="<?php echo e($day->token); ?>" name="token" id="whatsToken" /><br>

                <button class="btn btn-primary" type="submit">حفظ</button>
            </form>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('AJAX'); ?>
    <script src="https://cdn.ckeditor.com/4.19.0/standard/ckeditor.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') } });


        });
    </script>
    <script>
        CKEDITOR.replace( 'content' );
        CKEDITOR.replace( 'contentEn' );
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\multi\multi\resources\views/admin/conf/whatsapp.blade.php ENDPATH**/ ?>