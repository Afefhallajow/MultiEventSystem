<div id="preloader">
   <!--<div id="status" style="top: 20%;">-->
   <!--   <div class="spinner-chase">-->
   <!--      <div class="chase-dot"></div>-->
   <!--      <div class="chase-dot"></div>-->
   <!--      <div class="chase-dot"></div>-->
   <!--      <div class="chase-dot"></div>-->
   <!--      <div class="chase-dot"></div>-->
   <!--      <div class="chase-dot"></div>-->
   <!--   </div>-->
   <!--</div>-->

   <!--<img style="position: absolute; top: 230px; left: 50%; transform: translateX(-50%);" -->
   <!--src="<?php echo e(asset('images')); ?>/fav.png" />-->
    <!--<img style="position: absolute; top: -170px; left: 50%; transform: translateX(-50%);" -->
    <!--    src="<?php echo e(asset('images')); ?>/cc.gif" />-->
    <div class="d-flex justify-content-center">
    <div class="spinner-border" style="color:rgb(20, 130, 135);width: 4rem; height: 4rem;text-align:center;margin:15rem auto" role="status">
      <span class="sr-only">Loading...</span>
    </div>
    </div>
</div>
<?php /**PATH C:\Users\HP\Desktop\multi\multi\resources\views/admin/includes/loader.blade.php ENDPATH**/ ?>