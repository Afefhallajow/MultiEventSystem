<!--- SIDEMENU -->
<div class="topnav">
    <div class="container-fluid">
        <nav class="navbar navbar-light navbar-expand-lg topnav-menu">
            <div class="collapse navbar-collapse" id="topnav-menu-content">
                <ul class="navbar-nav">
                    
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-dashboard" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="bx bx-home-circle ml-2"></i><span key="t-dashboards">لوحة التحكم</span> <div class="arrow-down mr-2"></div>

                        </a>
                        <div class="dropdown-menu <?php echo \Lang::locale() == 'ar' ? 'arabic' : 'english'; ?>" aria-labelledby="topnav-event">
                            <a href="<?php echo e(route('employees.index')); ?>"class="dropdown-item">الموظفون</a>
                        </div>

                    </li>

                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                    

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-event" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-calendar-check ml-2"></i><span key="t-events">الفعاليات</span> <div class="arrow-down mr-2"></div>
                        </a>
                        <div class="dropdown-menu <?php echo \Lang::locale() == 'ar' ? 'arabic' : 'english'; ?>" aria-labelledby="topnav-event">
                            <a href="<?php echo e(route('days.index')); ?>"class="dropdown-item">الفعاليات</a>
                            <a href="<?php echo e(route('places.index')); ?>" class="dropdown-item">المناطق</a>
                            <a href="<?php echo e(route('invites.index')); ?>" class="dropdown-item">جميع الدعوات</a>
                        </div>
                    </li>
<?php else: ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-event" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-calendar-check ml-2"></i><span key="t-events">الفعاليات</span> <div class="arrow-down mr-2"></div>
                            </a>
                            <div class="dropdown-menu <?php echo \Lang::locale() == 'ar' ? 'arabic' : 'english'; ?>" aria-labelledby="topnav-event">
                                <a href="<?php echo e(route('days.index')); ?>"class="dropdown-item">الفعاليات</a>
                                <a href="<?php echo e(route('places.index')); ?>" class="dropdown-item">المناطق</a>
                                <a href="<?php echo e(route('getInvited')); ?>" class="dropdown-item">جميع الدعوات</a>
                            </div>
                        </li>

                    <?php endif; ?>
                    
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-event" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-calendar-check ml-2"></i><span key="t-events">تسجيل الحضور</span> <div class="arrow-down mr-2"></div>
                            </a>
                            <div class="dropdown-menu <?php echo \Lang::locale() == 'ar' ? 'arabic' : 'english'; ?>" aria-labelledby="topnav-event">
                                <a href="<?php echo e(route('presencenew')); ?>"class="dropdown-item">تسجيل الحضور</a>
                                <a href="<?php echo e(route('presence.index')); ?>" class="dropdown-item">الحضور ضمن الفعاليات</a>
                            </div>
                        </li>
                    
                    <li class="nav-item dropdown">
                        <a href="<?php echo e(route('qrcode.index')); ?>" class="nav-link dropdown-toggle arrow-none">
                            <i class="fas fa-qrcode ml-2"></i><span>QR Code</span>
                        </a>
                    </li>

                </ul>
            </div>
        </nav>
    </div>
</div>
<?php /**PATH C:\Users\HP\Desktop\multi\multi\resources\views/admin/includes/sidemenu.blade.php ENDPATH**/ ?>