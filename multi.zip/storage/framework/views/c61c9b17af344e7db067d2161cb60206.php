
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <meta name="description" content="بوابة وزارة الموارد البشرية والتنمية الاجتماعية في المملكة العربية السعودية" />
   <meta name="abstract" content="أنشئت وزارة العمل والتنمية الاجتماعية بموجب المرسوم الملكي الكريم الذي صدر في الشهر الأخير من عام 1380 هـ، وذلك تحت اسم وزارة العمل والشؤون الاجتماعية، وقامت الوزارة منذ نشأتها بتنمية المجتمعات المحلية واهتمت بلجان المجتمع ومجالس المحافظات والمراكز والهجر ورعاية الشباب والأسرة والجمعيات التعاونية، وحددت الوزارة أهدافها" />
   <meta name="keywords" content="العمل,التنمية,الضمان,الرعاية,وزراة العمل" />

   <!-- App favicon -->
   <link rel="shortcut icon" href="<?php echo e(asset('images')); ?>/fav.png">

   <!-- CSRF Token -->
   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

   <title><?php echo $__env->yieldContent('title'); ?></title>

   <!-- DataTables -->

    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
   <link href="<?php echo e(asset('admin')); ?>/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
   <link href="<?php echo e(asset('admin')); ?>/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />

   <!-- Responsive datatable examples -->
   <link href="<?php echo e(asset('admin')); ?>/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />

   <!-- Bootstrap Css -->
   <link href="<?php echo e(asset('admin/css')); ?>/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />

   <!-- ColorPicker -->
   <link href="<?php echo e(asset('admin')); ?>/libs/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet" type="text/css" />

   <!-- Datepicker -->
   <link href="<?php echo e(asset('admin')); ?>/libs/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
   <link href="<?php echo e(asset('admin')); ?>/libs/@chenfengyuan/datepicker/datepicker.min.css" rel="stylesheet" type="text/css" />

   <!-- twitter-bootstrap-wizard css -->
   <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/libs/twitter-bootstrap-wizard/prettify.css">

   <!-- Icons Css -->
   <link href="<?php echo e(asset('admin/css')); ?>/icons.min.css" rel="stylesheet" type="text/css" />

   <!-- App Css-->
   <link href="<?php echo e(asset('admin/css')); ?>/app.min.css" id="app-style" rel="stylesheet" type="text/css" />

   <!-- Styles -->
   <link href="<?php echo e(asset('admin/css/style.css')); ?>" rel="stylesheet">

   <!-- Translation -->
   <span id="Forbidden" translation="<?php echo e(__('dashboard.Forbidden')); ?>"></span>
    <style>
        .page-item.active .page-link {
            background-color: rgb(20, 130, 135) !important;
            border-color: rgb(20, 130, 135) !important;
        }
        .topnav .navbar-nav .dropdown.active > a {
            color: rgb(20, 130, 135) !important;
            border-color: rgb(20, 130, 135) !important;
        }
        .topnav .navbar-nav .dropdown-item.active, .topnav .navbar-nav .dropdown-item:hover {
            color: rgb(20, 130, 135) !important;
        }
        .dataTables_wrapper .dt-buttons{
            float:left;
margin-right: 3%        }
        #records_table_filter{
            float: left;
            margin-top: 2%;
        }
    </style>
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body class="<?php echo \Lang::locale() == 'ar' ? 'arabic' : 'english'; ?>" data-topbar="dark" style="min-height: auto" data-layout="horizontal">
   <!-- Loader -->
   <?php echo $__env->make('admin.includes.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <div id="layout-wrapper">
      <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <?php echo $__env->make('admin.includes.sidemenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <div class="main-content">
         <?php echo $__env->yieldContent('content'); ?>

         <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
   </div>
</body>

</html>
<?php /**PATH C:\Users\HP\Desktop\multi\multi\resources\views/layouts/admin.blade.php ENDPATH**/ ?>