<div class="row">
   <div class="col-12">
      <div class="page-title-box d-flex align-items-center justify-content-between">
         <div class="page-title-right">
            <ol class="breadcrumb m-0">
               <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e($title); ?></a></li>
               <?php if(isset($supTitle)): ?>
               <li class="breadcrumb-item active"><?php echo e($supTitle); ?></li>
               <?php endif; ?>
            </ol>
         </div>
      </div>
   </div>
</div>
<?php /**PATH C:\Users\HP\Desktop\multi\multi\resources\views/admin/includes/page_title.blade.php ENDPATH**/ ?>