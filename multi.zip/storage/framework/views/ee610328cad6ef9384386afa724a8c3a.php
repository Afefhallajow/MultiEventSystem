<?php $__env->startSection('title'); ?>
    إعدادات الإيميل
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <!-- page title -->
            <?php echo $__env->make('admin.includes.page_title', ['title'=>'الفعاليات','supTitle' => 'إعدادات الإيميل'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <h4><?php echo e($day->name); ?></h4>
            <!-- Content -->
            <form action="<?php echo e(url()->current()); ?>" method="post">
                <?php echo csrf_field(); ?>
                <label>عنوان الإيميل</label>
                <input type="text" class="form-control" name="subject" id="subject" value="<?php echo e($config->subject); ?>"/>
                <label>عنوان الإيميل الأجنبي</label>
                <input type="text" class="form-control" name="subjectEn" id="subjectEn" value="<?php echo e($config->subjectEn); ?>"/>
                <label>محتوى إيميل الشهادة</label>
                <textarea name="content"><?php echo $config->confirm_content; ?></textarea>
            <!--<input type="text" class="form-control" name="content" id="content" value="<?php echo e($config->confirm_content); ?>"/>-->
                <label>محتوى إيميل الدعوة</label>
                <textarea name="contentEn"><?php echo $config->confirm_content_en; ?></textarea>
            <!--<input type="text" class="form-control" name="contentEn" id="contentEn" value="<?php echo e($config->confirm_content_en); ?>" /><br>--><br>
                <label>محتوى إيميل التسجيل الخارجي</label>
                <textarea name="invite_content"><?php echo $config->invite_content; ?></textarea>


                <button class="btn btn-primary" type="submit">حفظ</button>
            </form>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('AJAX'); ?>
    <script src="https://cdn.ckeditor.com/4.19.0/standard/ckeditor.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') } });

            $(document).on('change', 'select', function () {
                let id = <?php echo e($day->id); ?>;
                let url = "/getEmailConfig/"+id
                $.ajax({
                    url: url,
                    method : "GET",
                    success: function (data) {

                            document.getElementById('subject').value = data.confirm_subject;
                            document.getElementById('subjectEn').value = data.confirm_subject_en;
                            CKEDITOR.instances['content'].setData(data.confirm_content);
                            CKEDITOR.instances['contentEn'].setData(data.confirm_content_en);
                        CKEDITOR.instances['invite_content'].setData(data.invite_content);

                        }

                });
            });

        });
    </script>
    <script>
        CKEDITOR.replace( 'content' );
        CKEDITOR.replace( 'contentEn' );
        CKEDITOR.replace( 'invite_content' );

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\multi\multi\resources\views/email/emailConf.blade.php ENDPATH**/ ?>