<div class="modal-header">
    <h4 class="modal-title mrAuto" align="center">تعديل الصلاحيات</h4>
</div>
<form class="form-horizontal" method="post" id="permission_form">
    <div id="permission_result"></div>
    <div class="modal-body">
        <div class="form-group row justify-content-end">
            <div class="col-sm-12">
                <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $checked = $user->hasPermissionTo($value->id) ? 'checked=true' : '';
                    ?>
                    <label style="cursor: pointer">
                        <input type="checkbox" name="permission[]" value="<?php echo e($value->id); ?>" class="form-controller" <?php echo e($checked); ?>>
                        <?php echo e(__('dashboard.'.$value->name)); ?>

                    </label>
                    <br/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <!-- submit -->
        <div class="form-group row justify-content-end">
            <div class="col-sm-9">
                <input type="hidden" name="user_id" id="user_id" value="<?php echo e($user->id); ?>" />
                <input type="submit" name="action_button" id="permission_button" class="blueColor btn btn-light" value="حفظ"
                       style="padding:8px 40px;" />
                <div id="permission_spinner" class="spinner-grow text-secondary m-1 blueColor" role="status" style="display: none">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>
        </div>
    </div>
</form>
<?php /**PATH C:\Users\HP\Desktop\multi\multi\resources\views/admin/includes/permissions.blade.php ENDPATH**/ ?>