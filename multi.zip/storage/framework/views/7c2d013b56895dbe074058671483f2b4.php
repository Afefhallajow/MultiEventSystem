<!--=================================
header start-->

<section style="background-color: white" id="navigation1" class="">
<div  id="content">
    <img src="<?php echo e(URL::asset('logo/1.png')); ?>" style="max-height: 140px" alt="Gantry 5"></div>
</section>
<?php /**PATH C:\Users\HP\Desktop\multi\multi\resources\views/layouts/main-header.blade.php ENDPATH**/ ?>